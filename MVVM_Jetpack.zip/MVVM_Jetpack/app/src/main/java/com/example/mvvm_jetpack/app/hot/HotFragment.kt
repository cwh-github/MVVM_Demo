package com.example.mvvm_jetpack.app.hot

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.fragment.app.Fragment
import com.example.mvvm_jetpack.R
import com.example.mvvm_jetpack.app.home.HomeFragment
import com.example.mvvm_jetpack_lib.base.widget.StateLayout

/**
 * Description:
 * Date：2019/7/22-19:13
 * Author: cwh
 */
class HotFragment :Fragment(){


    private var mFragmentView: View?=null
    private lateinit var mStatLayout: StateLayout

    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?): View? {
        if(mFragmentView==null){
            mFragmentView=inflater.inflate(R.layout.fragment_hot,container,false)
            mStatLayout= StateLayout(activity!!).wrap(mFragmentView).showContentView()
        }
        return mStatLayout
    }


    companion object{


            fun newInstance(tag: String): HotFragment {
                val fragment = HotFragment()
                val bundle = Bundle()
                bundle.putString("tag", tag)
                fragment.arguments = bundle
                return fragment
            }

    }
}