package com.example.mvvm_jetpack

import com.example.mvvm_jetpack_lib.base.BaseApplication
import com.example.mvvm_jetpack_lib.utils.ConUtils
import com.example.mvvm_jetpack_lib.utils.CrashHandlerUtils

/**
 * Description:
 * Date：2019/7/19-14:34
 * Author: cwh
 */
class MyApplication :BaseApplication(){
    override fun init() {

    }

}