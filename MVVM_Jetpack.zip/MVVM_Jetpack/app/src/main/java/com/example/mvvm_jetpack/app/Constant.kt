package com.example.mvvm_jetpack.app

/**
 * Description:
 * Date：2019/7/19-16:36
 * Author: cwh
 */

/**
 * 登录需要的参数，需要在github申请
 */
const val CLIENT_ID="e565990db6f1877986a1"
const val CLIENT_SECRET="a43133c7611accfefac0a640e8bcd6ac1d2008ca"