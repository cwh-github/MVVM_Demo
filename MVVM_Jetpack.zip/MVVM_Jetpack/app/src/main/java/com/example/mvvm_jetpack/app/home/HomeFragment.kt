package com.example.mvvm_jetpack.app.home

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.databinding.DataBindingUtil
import com.example.mvvm_jetpack.BR
import com.example.mvvm_jetpack.R
import com.example.mvvm_jetpack.databinding.HomeDataBinding
import com.example.mvvm_jetpack_lib.base.view.BaseFragment
import com.example.mvvm_jetpack_lib.base.widget.StateLayout
import com.example.mvvm_jetpack_lib.utils.ConUtils

/**
 * Description:
 * Date：2019/7/22-18:59
 * Author: cwh
 */
class HomeFragment : BaseFragment<HomeViewModel, HomeDataBinding>() {
    override val mViewModel: HomeViewModel by lazy {
        HomeViewModel(HomeRepository(), ConUtils.mApplication())
    }
    override val layoutId: Int = R.layout.fragment_home
    override var mViewModelVariableId: Int = BR.viewModel

    lateinit var mStateLayout: StateLayout

    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?): View? {
        mStateLayout =
            StateLayout(mActivity.applicationContext).wrap(super.onCreateView(inflater, container, savedInstanceState))
                .showContentView()
        return mStateLayout
    }

    override fun initDataAndView() {
        super.initDataAndView()

    }

    override fun initViewObserver() {

    }


    companion object {


        fun newInstance(tag: String): HomeFragment {
            val fragment = HomeFragment()
            val bundle = Bundle()
            bundle.putString("tag", tag)
            fragment.arguments = bundle
            return fragment
        }

    }
}