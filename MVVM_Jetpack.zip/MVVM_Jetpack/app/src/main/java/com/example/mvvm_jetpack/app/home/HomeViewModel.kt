package com.example.mvvm_jetpack.app.home

import android.app.Application
import com.example.mvvm_jetpack_lib.base.viewmodel.BaseViewModel

/**
 * Description:
 * Date：2019/7/22-21:03
 * Author: cwh
 */
class HomeViewModel(repo: HomeRepository, application: Application) :
    BaseViewModel<HomeRepository>(repo, application){

}