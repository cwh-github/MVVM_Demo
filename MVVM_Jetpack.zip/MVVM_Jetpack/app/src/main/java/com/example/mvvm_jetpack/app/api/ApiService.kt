package com.example.mvvm_jetpack.app.api

import com.example.mvvm_jetpack.app.bean.AuthRequestBean
import com.example.mvvm_jetpack.app.bean.AuthUser
import io.reactivex.Observable
import retrofit2.http.Body
import retrofit2.http.Header
import retrofit2.http.Headers
import retrofit2.http.POST

/**
 * Description:
 * Date：2019/7/19-16:27
 * Author: cwh
 */
interface ApiService {

    /**
     * 登录请求
     *
     * @param  authHeader 由password 和 username 生成
     */
    @POST("authorizations")
    @Headers("Accept: application/json")
    fun login(
        @Header("Authorization") authHeader: String,
        @Body authRequestBean: AuthRequestBean
    ): Observable<AuthUser>
}