package com.example.mvvm_jetpack.app.home

import com.example.mvvm_jetpack_lib.base.repository.BaseRepositoryRemote

/**
 * Description:
 * Date：2019/7/22-21:02
 * Author: cwh
 */
class HomeRepository : BaseRepositoryRemote() {

}