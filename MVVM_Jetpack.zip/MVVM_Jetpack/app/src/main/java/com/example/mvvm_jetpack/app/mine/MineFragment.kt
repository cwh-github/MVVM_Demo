package com.example.mvvm_jetpack.app.mine

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.fragment.app.Fragment
import com.example.mvvm_jetpack.R
import com.example.mvvm_jetpack_lib.base.widget.StateLayout

/**
 * Description:
 * Date：2019/7/22-19:14
 * Author: cwh
 */
class MineFragment : Fragment() {

    private var mFragmentView: View?=null
    private lateinit var mStatLayout: StateLayout

    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?): View? {
        if(mFragmentView==null){
            mFragmentView=inflater.inflate(R.layout.fragment_mine,container,false)
            mStatLayout= StateLayout(activity!!).wrap(mFragmentView).showContentView()
        }
        return mStatLayout
    }


    companion object {

            fun newInstance(tag: String): MineFragment {
                val fragment = MineFragment()
                val bundle = Bundle()
                bundle.putString("tag", tag)
                fragment.arguments = bundle
                return fragment
            }

    }
}