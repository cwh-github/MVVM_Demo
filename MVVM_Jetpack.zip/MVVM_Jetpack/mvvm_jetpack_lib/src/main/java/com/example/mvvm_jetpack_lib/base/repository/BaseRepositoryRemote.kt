package com.example.mvvm_jetpack_lib.base.repository

/**
 * Description:
 *
 *
 * Date：2019/7/17-13:53
 * Author: cwh
 */
open class BaseRepositoryRemote : IRepository {

    override fun onClear() {

    }
}