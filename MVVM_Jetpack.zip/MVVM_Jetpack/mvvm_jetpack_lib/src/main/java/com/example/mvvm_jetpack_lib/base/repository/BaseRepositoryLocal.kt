package com.example.mvvm_jetpack_lib.base.repository

/**
 * Description:
 * Date：2019/7/17-14:25
 * Author: cwh
 */
open class BaseRepositoryLocal : IRepository {
    override fun onClear() {

    }
}