package com.example.mvvm_jetpack_lib.base

/**
 * Description:
 * Date：2019/7/16-18:21
 * Author: cwh
 */
open class Entity<T>(val msg:String, val code:Int, var t:T)