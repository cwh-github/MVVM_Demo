package com.example.mvvm_jetpack_lib.base.widget

/**
 * Description:
 * Date：2019/7/22-10:51
 * Author: cwh
 */
enum class State {
    //正在加载
    LOADING,
    //数据为空
    EMPTY,
    //加载失败
    ERROR,
    //加载成功，显示content
    CONTENT
}